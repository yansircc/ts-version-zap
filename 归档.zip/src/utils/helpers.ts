// src/utils/helpers.ts
export function isAllowedToProcess(chatId: string, excludedNumbersIntervention: Map<string, boolean>): boolean {
    // 实现根据逻辑来决定是否允许处理该消息
    return true; // 示例，默认允许处理
}